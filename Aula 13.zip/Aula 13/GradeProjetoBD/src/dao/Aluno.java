
package dao;


public class Aluno {
    
    private String rgm;
    private String nome;
    private String curso;

    public String getRgm() {
        return rgm;
    }

    public String getNome() {
        return nome;
    }

    public String getCurso() {
        return curso;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    
    
}
